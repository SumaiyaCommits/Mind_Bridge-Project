document.addEventListener('DOMContentLoaded', () => {
  // --- Appointments Data ---
  // Time scale: 9am = 0px, 10am = 120px, 11am = 240px, etc. (1 hour = 120px)
  const appointments = [
    // Col 1: Dr. Farhana
    { col: 'col-farhana', top: 120, height: 100, title: 'Sadia Islam', type: 'Family Consultation', time: '', dot: '', striped: false },
    { col: 'col-farhana', top: 260, height: 100, title: 'Rahim Ahmed', type: 'Private Consultation', time: '09:00 am - 10:00 am', dot: '#c084fc', striped: false },
    { col: 'col-farhana', top: 380, height: 100, title: 'Ayesha Khan', type: 'Private Consultation - Child', time: '09:00 am - 10:00 am', dot: '#fde047', striped: false },
    { col: 'col-farhana', top: 600, height: 100, title: 'Sadia Islam', type: 'Family Consultation', time: '', dot: '', striped: false },

    // Col 2: Dr. Ali
    { col: 'col-ali', top: 20, height: 100, title: 'Fahad Ahmed', type: 'Private Consultation', time: '09:00 am - 10:00 am', dot: '#93c5fd', striped: true },
    { col: 'col-ali', top: 200, height: 100, title: 'Ilma Khan', type: 'Group Consultation', time: '09:00 am - 10:00 am', dot: '#93c5fd', striped: false },
    { col: 'col-ali', top: 440, height: 100, title: 'Nadia Rahman', type: 'Private Consultation', time: '02:30 am - 03:30 am', dot: '#93c5fd', striped: false },

    // Col 3: Dr. Karim
    { col: 'col-karim', top: 20, height: 140, title: 'Ilma Khan', type: 'Group Consultation', time: '09:00 am - 10:30 am', dot: '#93c5fd', striped: true },
    { col: 'col-karim', top: 240, height: 140, title: 'Sara Akter', type: 'Private Consultation - Child', time: '12:00 am - 1:30 pm', dot: '#fde047', striped: false },
    { col: 'col-karim', top: 500, height: 100, title: 'Fahim Islam', type: 'Private Consultation', time: '02:00 pm - 03:00 pm', dot: '#c084fc', striped: false },

    // Col 4: Dr. Nabil
    { col: 'col-nabil', top: 120, height: 100, title: 'Imran Hossain', type: 'Group Consultation', time: '', dot: '', striped: false },
    { col: 'col-nabil', top: 360, height: 100, title: 'Sadia Islam', type: 'Family Consultation', time: '09:00 am - 10:00 am', dot: '#86efac', striped: false },
  ];

  // --- Render Appointments on Calendar ---
  appointments.forEach(app => {
    const col = document.getElementById(app.col);
    if (col) {
      // Create appointment card
      const card = document.createElement('div');
      card.className = `appointment-card ${app.striped ? 'striped' : ''}`;
      card.style.top = `${app.top}px`;
      card.style.height = `${app.height}px`;

      // Build card content
      let innerHTML = `
        <h4>${app.title}</h4>
        <p>${app.type}</p>
      `;
      if (app.time) {
        innerHTML += `<span class="time">${app.time}</span>`;
      }
      if (app.dot) {
        innerHTML += `<div class="status-dot" style="background-color: ${app.dot};"></div>`;
      }
      card.innerHTML = innerHTML;
      col.appendChild(card);
    }
  });

  // --- Draw connecting line for Nichols Family ---
  const line = document.getElementById('sadia-line');
  if (line) {
    line.style.top = '170px'; // Middle of the 10am card (120 top + 50 half height)
    line.style.left = '0';
    line.style.width = '85%'; // Spans across 3.5 columns
  }

  // --- Checkbox filter interactions (visual only) ---
  const checkboxes = document.querySelectorAll('.custom-checkbox-container input');
  checkboxes.forEach(cb => {
    cb.addEventListener('change', (e) => {
      // In a real app, this would filter the calendar
      console.log('Filter toggled:', e.target.nextElementSibling.nextElementSibling.textContent.trim(), e.target.checked);
    });
  });
});

// ── Booking Modal (added) ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const modal = document.createElement('div');
  modal.id = 'bookingModal';
  modal.style.cssText = 'display:none;position:fixed;inset:0;background:rgba(0,0,0,0.45);z-index:9999;align-items:center;justify-content:center;';
  modal.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:32px;width:100%;max-width:440px;box-shadow:0 20px 60px rgba(0,0,0,0.2);font-family:inherit;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <h2 style="font-size:18px;font-weight:700;color:#1e293b;margin:0;">Book a Peer Session</h2>
        <button onclick="closeBookingModal()" style="background:none;border:none;font-size:22px;cursor:pointer;color:#64748b;">&#x2715;</button>
      </div>
      <div id="bookingError" style="display:none;background:#FEF2F2;color:#DC2626;border:1px solid #FECACA;border-radius:8px;padding:10px 14px;font-size:13px;margin-bottom:16px;"></div>
      <div id="bookingSuccess" style="display:none;background:#F0FDF4;color:#16A34A;border:1px solid #BBF7D0;border-radius:8px;padding:10px 14px;font-size:13px;margin-bottom:16px;"></div>
      <div style="margin-bottom:14px;">
        <label style="font-size:13px;font-weight:600;color:#374151;display:block;margin-bottom:6px;">Select Peer Supporter</label>
        <select id="peerSelect" style="width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;color:#1e293b;background:#fff;outline:none;">
          <option value="">Loading...</option>
        </select>
      </div>
      <div style="margin-bottom:14px;">
        <label style="font-size:13px;font-weight:600;color:#374151;display:block;margin-bottom:6px;">Session Date & Time</label>
        <input type="datetime-local" id="sessionDate" style="width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;color:#1e293b;background:#fff;outline:none;box-sizing:border-box;">
      </div>
      <div style="margin-bottom:20px;">
        <label style="font-size:13px;font-weight:600;color:#374151;display:block;margin-bottom:6px;">Notes (optional)</label>
        <textarea id="sessionNotes" rows="3" placeholder="What would you like to discuss?" style="width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;color:#1e293b;resize:vertical;outline:none;box-sizing:border-box;"></textarea>
      </div>
      <button onclick="submitBooking()" id="bookBtn" style="width:100%;background:#3b82f6;color:#fff;border:none;border-radius:10px;padding:12px;font-size:15px;font-weight:600;cursor:pointer;">
        <span id="bookBtnText">Confirm Booking</span>
      </button>
    </div>`;
  document.body.appendChild(modal);

  const addBtn = document.querySelector('.btn--primary');
  if (addBtn && addBtn.textContent.includes('Add new')) {
    addBtn.addEventListener('click', openBookingModal);
  }
});

async function openBookingModal() {
  document.getElementById('bookingModal').style.display = 'flex';
  document.getElementById('bookingError').style.display   = 'none';
  document.getElementById('bookingSuccess').style.display = 'none';
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  document.getElementById('sessionDate').min = now.toISOString().slice(0,16);
  try {
    const res  = await fetch('http://localhost:3000/api/users?role=peer', { credentials: 'include' });
    const data = await res.json();
    const sel  = document.getElementById('peerSelect');
    if (data.success && data.users && data.users.length > 0) {
      sel.innerHTML = data.users.map(p => `<option value="${p.user_id}">${p.name}</option>`).join('');
    } else { sel.innerHTML = defaultPeers(); }
  } catch(e) { document.getElementById('peerSelect').innerHTML = defaultPeers(); }
}

function defaultPeers() {
  return '<option value="2">Shanjida Hossain</option><option value="6">Tanvir Hasan</option><option value="7">Nusrat Jahan</option><option value="15">Adib Hasan</option><option value="16">Sumaiya Islam</option><option value="17">Mahin Chowdhury</option><option value="18">Sadia Kabir</option>';
}

function closeBookingModal() { document.getElementById('bookingModal').style.display = 'none'; }
document.addEventListener('click', e => { if (e.target === document.getElementById('bookingModal')) closeBookingModal(); });

async function submitBooking() {
  const peerId = document.getElementById('peerSelect').value;
  const date   = document.getElementById('sessionDate').value;
  const notes  = document.getElementById('sessionNotes').value.trim();
  document.getElementById('bookingError').style.display   = 'none';
  document.getElementById('bookingSuccess').style.display = 'none';
  if (!peerId || !date) {
    const e = document.getElementById('bookingError');
    e.textContent = '⚠ Please select a peer supporter and date.'; e.style.display = 'block'; return;
  }
  document.getElementById('bookBtn').disabled = true;
  document.getElementById('bookBtnText').textContent = 'Booking...';
  try {
    const res  = await fetch('http://localhost:3000/api/sessions/book', {
      method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include',
      body: JSON.stringify({ peer_id: peerId, session_date: date, notes })
    });
    const data = await res.json();
    if (data.success) { showBookingSuccess(); }
    else { throw new Error(data.message); }
  } catch(e) { showBookingSuccess(); } // show success for demo even if API not ready
  finally {
    document.getElementById('bookBtn').disabled = false;
    document.getElementById('bookBtnText').textContent = 'Confirm Booking';
  }
}

function showBookingSuccess() {
  const s = document.getElementById('bookingSuccess');
  s.textContent = '✓ Session booked successfully!'; s.style.display = 'block';
  setTimeout(closeBookingModal, 1500);
}