/**
 * auth-guard.js
 * Checks login session and enforces role access on every protected page.
 * Usage: <script src="../js/auth-guard.js" data-role="student,peer,supervisor"></script>
 */
const API_BASE = 'http://localhost:3000/api';

(async () => {
  const scriptTag    = document.currentScript || document.querySelector('script[data-role]');
  const allowedRoles = scriptTag ? scriptTag.getAttribute('data-role').split(',').map(r => r.trim()) : [];

  let user = null;
  try {
    const res  = await fetch(API_BASE + '/auth/me', { credentials: 'include' });
    const data = await res.json();
    if (data.success && data.user) user = data.user;
  } catch(e) {}

  // Not logged in → go to login
  if (!user) { window.location.href = 'login.html'; return; }

  // Wrong role → redirect to their correct page
  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    if      (user.role === 'student')    window.location.href = 'index.html';
    else if (user.role === 'peer')       window.location.href = 'schedule.html';
    else if (user.role === 'supervisor') window.location.href = 'clinical.html';
    return;
  }

  // Update greeting with real name
  const greeting = document.querySelector('.topbar__greeting');
  if (greeting) greeting.innerHTML = 'Welcome back, <strong>' + user.name + '</strong>! <span class="wave">\uD83D\uDE4C</span>';

  // Update profile picture
  const pic = document.querySelector('.profile-pic');
  if (pic) pic.src = 'https://ui-avatars.com/api/?name=' + encodeURIComponent(user.name) + '&background=0D8ABC&color=fff';

  // Make user available globally for other scripts
  window.currentUser = user;
})();

// Logout — available on every page
async function handleLogout() {
  try { await fetch(API_BASE + '/auth/logout', { method: 'POST', credentials: 'include' }); } catch(e) {}
  window.location.href = 'login.html';
}
