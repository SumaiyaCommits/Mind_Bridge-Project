// controllers/alertController.js
// Supervisors can view and manage high-risk alerts.

const db = require('../config/db');

// ─── GET /api/alerts ──────────────────────────────────────────────────────
// Supervisor only. Returns all alerts with linked report details.

exports.getAlerts = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT a.alert_id, a.alert_type, a.status, a.created_at,
              r.report_id, r.description, r.risk_level, r.report_type,
              CASE WHEN r.report_type = 'anonymous' THEN 'Anonymous' ELSE u.name END AS student_name
       FROM alerts a
       LEFT JOIN reports r ON a.report_id = r.report_id
       LEFT JOIN users u ON r.student_id = u.user_id
       ORDER BY a.created_at DESC`
    );

    res.json({ success: true, alerts: rows });
  } catch (err) {
    console.error('GetAlerts error:', err);
    res.status(500).json({ success: false, message: 'Server error fetching alerts.' });
  }
};

// ─── PATCH /api/alerts/:id/status ────────────────────────────────────────
// Supervisor acknowledges or resolves an alert.

exports.updateAlertStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['unread', 'acknowledged', 'resolved'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Status must be unread, acknowledged, or resolved.' });
    }

    const [result] = await db.query(
      'UPDATE alerts SET status = ? WHERE alert_id = ?',
      [status, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Alert not found.' });
    }

    res.json({ success: true, message: `Alert marked as '${status}'.` });
  } catch (err) {
    console.error('UpdateAlertStatus error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ─── GET /api/alerts/unread-count ────────────────────────────────────────
// Quick count for notification badge in topbar.

exports.getUnreadCount = async (req, res) => {
  try {
    const [[{ count }]] = await db.query(
      "SELECT COUNT(*) AS count FROM alerts WHERE status = 'unread'"
    );
    res.json({ success: true, count });
  } catch (err) {
    console.error('GetUnreadCount error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};
