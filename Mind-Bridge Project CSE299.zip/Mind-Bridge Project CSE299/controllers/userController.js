// controllers/userController.js
// Returns user listings for clinical dashboard and schedule page.

const db = require('../config/db');

// ─── GET /api/users ───────────────────────────────────────────────────────
// Supervisor only — get all users. Optional ?role= filter.

exports.getUsers = async (req, res) => {
  try {
    const { role } = req.query;
    const validRoles = ['student', 'peer', 'supervisor'];

    let query  = 'SELECT user_id, name, email, role, specialization, created_at FROM users ORDER BY created_at DESC';
    let params = [];

    if (role && validRoles.includes(role)) {
      query  = 'SELECT user_id, name, email, role, specialization, created_at FROM users WHERE role = ? ORDER BY name';
      params = [role];
    }

    const [rows] = await db.query(query, params);
    res.json({ success: true, users: rows });
  } catch (err) {
    console.error('GetUsers error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ─── GET /api/users/:id ───────────────────────────────────────────────────

exports.getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await db.query(
      'SELECT user_id, name, email, role, specialization, created_at FROM users WHERE user_id = ?',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    res.json({ success: true, user: rows[0] });
  } catch (err) {
    console.error('GetUserById error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ─── GET /api/users/dashboard-stats ──────────────────────────────────────
// Supervisor dashboard summary stats.

exports.getDashboardStats = async (req, res) => {
  try {
    const [[{ total_students }]] = await db.query(
      "SELECT COUNT(*) AS total_students FROM users WHERE role = 'student'"
    );
    const [[{ total_peers }]] = await db.query(
      "SELECT COUNT(*) AS total_peers FROM users WHERE role = 'peer'"
    );
    const [[{ active_cases }]] = await db.query(
      "SELECT COUNT(*) AS active_cases FROM reports WHERE status = 'active'"
    );
    const [[{ high_risk_cases }]] = await db.query(
      "SELECT COUNT(*) AS high_risk_cases FROM reports WHERE risk_level = 'high' AND status != 'closed'"
    );
    const [[{ unread_alerts }]] = await db.query(
      "SELECT COUNT(*) AS unread_alerts FROM alerts WHERE status = 'unread'"
    );

    res.json({
      success: true,
      stats: { total_students, total_peers, active_cases, high_risk_cases, unread_alerts },
    });
  } catch (err) {
    console.error('GetDashboardStats error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};
