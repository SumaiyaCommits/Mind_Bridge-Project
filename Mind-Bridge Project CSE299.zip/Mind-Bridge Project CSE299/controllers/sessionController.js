// controllers/sessionController.js
// Manages peer support session scheduling, viewing, and status updates.

const db = require('../config/db');

// ─── POST /api/sessions ────────────────────────────────────────────────────
// Create / book a new session. Only students can book, linked to a report.

exports.createSession = async (req, res) => {
  try {
    const { report_id, peer_id, session_date } = req.body;

    if (!report_id || !peer_id || !session_date) {
      return res.status(400).json({ success: false, message: 'report_id, peer_id, and session_date are required.' });
    }

    // Validate peer exists and has peer role
    const [peerRows] = await db.query(
      "SELECT user_id FROM users WHERE user_id = ? AND role = 'peer'",
      [peer_id]
    );
    if (peerRows.length === 0) {
      return res.status(404).json({ success: false, message: 'Peer supporter not found.' });
    }

    // Check the report belongs to the student
    const { user_id, role } = req.user;
    if (role === 'student') {
      const [repRows] = await db.query(
        'SELECT report_id FROM reports WHERE report_id = ? AND student_id = ?',
        [report_id, user_id]
      );
      if (repRows.length === 0) {
        return res.status(403).json({ success: false, message: 'You can only book sessions for your own reports.' });
      }
    }

    const [result] = await db.query(
      "INSERT INTO sessions (report_id, peer_id, session_date, status) VALUES (?, ?, ?, 'scheduled')",
      [report_id, peer_id, session_date]
    );

    // Mark the report as active once a session is booked
    await db.query("UPDATE reports SET status = 'active' WHERE report_id = ?", [report_id]);

    res.status(201).json({
      success: true,
      message: 'Session scheduled successfully.',
      session_id: result.insertId,
    });
  } catch (err) {
    console.error('CreateSession error:', err);
    res.status(500).json({ success: false, message: 'Server error scheduling session.' });
  }
};

// ─── GET /api/sessions ────────────────────────────────────────────────────
// Role-aware: students see their sessions, peers see their assigned sessions,
// supervisors see all sessions.

exports.getSessions = async (req, res) => {
  try {
    const { role, user_id } = req.user;
    let rows;

    const baseQuery = `
      SELECT s.session_id, s.session_date, s.status, s.notes,
             r.description AS report_description, r.risk_level, r.report_type,
             peer.name AS peer_name, peer.specialization AS peer_specialization,
             CASE WHEN r.report_type = 'anonymous' THEN 'Anonymous' ELSE stu.name END AS student_name
      FROM sessions s
      LEFT JOIN reports r ON s.report_id = r.report_id
      LEFT JOIN users peer ON s.peer_id = peer.user_id
      LEFT JOIN users stu ON r.student_id = stu.user_id
    `;

    if (role === 'supervisor') {
      [rows] = await db.query(baseQuery + ' ORDER BY s.session_date DESC');
    } else if (role === 'peer') {
      [rows] = await db.query(baseQuery + ' WHERE s.peer_id = ? ORDER BY s.session_date DESC', [user_id]);
    } else {
      // student: join through report -> student_id
      [rows] = await db.query(
        baseQuery + ' WHERE r.student_id = ? ORDER BY s.session_date DESC',
        [user_id]
      );
    }

    res.json({ success: true, sessions: rows });
  } catch (err) {
    console.error('GetSessions error:', err);
    res.status(500).json({ success: false, message: 'Server error fetching sessions.' });
  }
};

// ─── PATCH /api/sessions/:id ──────────────────────────────────────────────
// Update session status or add notes. Peers and supervisors only.

exports.updateSession = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, notes } = req.body;

    const validStatuses = ['scheduled', 'completed', 'cancelled'];
    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status.' });
    }

    const fields = [];
    const values = [];

    if (status) { fields.push('status = ?'); values.push(status); }
    if (notes !== undefined) { fields.push('notes = ?'); values.push(notes); }

    if (fields.length === 0) {
      return res.status(400).json({ success: false, message: 'No fields to update.' });
    }

    values.push(id);
    const [result] = await db.query(
      `UPDATE sessions SET ${fields.join(', ')} WHERE session_id = ?`,
      values
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Session not found.' });
    }

    // If session completed, close the report
    if (status === 'completed') {
      await db.query(
        "UPDATE reports SET status = 'closed' WHERE report_id = (SELECT report_id FROM sessions WHERE session_id = ?)",
        [id]
      );
    }

    res.json({ success: true, message: 'Session updated successfully.' });
  } catch (err) {
    console.error('UpdateSession error:', err);
    res.status(500).json({ success: false, message: 'Server error updating session.' });
  }
};

// ─── GET /api/sessions/peers ──────────────────────────────────────────────
// Returns list of available peer supporters (for booking dropdown on schedule page)

exports.getAvailablePeers = async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT user_id, name, specialization FROM users WHERE role = 'peer' ORDER BY name"
    );
    res.json({ success: true, peers: rows });
  } catch (err) {
    console.error('GetPeers error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};
