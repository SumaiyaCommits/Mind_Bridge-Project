// controllers/resourceController.js
// Manages mental health resources (articles, videos, guides, exercises).
// Students can view; supervisors can add/edit/delete.

const db = require('../config/db');

// ─── GET /api/resources ───────────────────────────────────────────────────
// Anyone logged in can view resources. Optional ?type= filter.

exports.getResources = async (req, res) => {
  try {
    const { type } = req.query;
    const validTypes = ['article', 'video', 'exercise', 'guide'];

    let query  = 'SELECT * FROM resources ORDER BY created_at DESC';
    let params = [];

    if (type && validTypes.includes(type)) {
      query  = 'SELECT * FROM resources WHERE resource_type = ? ORDER BY created_at DESC';
      params = [type];
    }

    const [rows] = await db.query(query, params);
    res.json({ success: true, resources: rows });
  } catch (err) {
    console.error('GetResources error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ─── POST /api/resources ──────────────────────────────────────────────────
// Supervisor only — add a new resource.

exports.createResource = async (req, res) => {
  try {
    const { title, description, resource_type, duration_minutes } = req.body;

    if (!title || !resource_type) {
      return res.status(400).json({ success: false, message: 'Title and resource_type are required.' });
    }

    const validTypes = ['article', 'video', 'exercise', 'guide'];
    if (!validTypes.includes(resource_type)) {
      return res.status(400).json({ success: false, message: 'resource_type must be article, video, exercise, or guide.' });
    }

    const [result] = await db.query(
      'INSERT INTO resources (title, description, resource_type, duration_minutes) VALUES (?, ?, ?, ?)',
      [title, description || null, resource_type, duration_minutes || null]
    );

    res.status(201).json({
      success: true,
      message: 'Resource added successfully.',
      resource_id: result.insertId,
    });
  } catch (err) {
    console.error('CreateResource error:', err);
    res.status(500).json({ success: false, message: 'Server error creating resource.' });
  }
};

// ─── PUT /api/resources/:id ───────────────────────────────────────────────
// Supervisor only — update a resource.

exports.updateResource = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, resource_type, duration_minutes } = req.body;

    const [result] = await db.query(
      'UPDATE resources SET title = ?, description = ?, resource_type = ?, duration_minutes = ? WHERE resource_id = ?',
      [title, description, resource_type, duration_minutes, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Resource not found.' });
    }

    res.json({ success: true, message: 'Resource updated successfully.' });
  } catch (err) {
    console.error('UpdateResource error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ─── DELETE /api/resources/:id ────────────────────────────────────────────
// Supervisor only — remove a resource.

exports.deleteResource = async (req, res) => {
  try {
    const { id } = req.params;
    const [result] = await db.query('DELETE FROM resources WHERE resource_id = ?', [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Resource not found.' });
    }

    res.json({ success: true, message: 'Resource deleted.' });
  } catch (err) {
    console.error('DeleteResource error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};
