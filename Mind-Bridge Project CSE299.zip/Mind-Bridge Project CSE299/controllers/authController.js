// controllers/authController.js
// Simple login/logout/register using express-session.
// No JWT. No bcrypt. Passwords stored and checked as plain text
// (matching the original seed data: '123456', 'pass123').

const db = require('../config/db');

// ── POST /api/auth/register ─────────────────────────────────────────────────

exports.register = async (req, res) => {
  try {
    const { name, email, password, role, specialization } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ success: false, message: 'Name, email, password and role are required.' });
    }

    const allowedRoles = ['student', 'peer', 'supervisor'];
    if (!allowedRoles.includes(role)) {
      return res.status(400).json({ success: false, message: 'Invalid role.' });
    }

    // Check email already exists
    const [existing] = await db.query('SELECT user_id FROM users WHERE email = ?', [email]);
    if (existing.length > 0) {
      return res.status(409).json({ success: false, message: 'An account with this email already exists.' });
    }

    // Insert — plain text password, same as seed data
    const [result] = await db.query(
      'INSERT INTO users (name, email, password, role, specialization) VALUES (?, ?, ?, ?, ?)',
      [name, email, password, role, specialization || null]
    );

    // Auto login after register
    const user = { user_id: result.insertId, name, email, role, specialization: specialization || null };
    req.session.user = user;

    res.status(201).json({ success: true, message: 'Account created.', user });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── POST /api/auth/login ────────────────────────────────────────────────────

exports.login = async (req, res) => {
  try {
    const { email, password, role } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email and password are required.' });
    }

    const [rows] = await db.query(
      'SELECT user_id, name, email, password, role, specialization FROM users WHERE email = ?',
      [email]
    );

    if (rows.length === 0) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const user = rows[0];

    // Plain text password check
    if (password !== user.password) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    // If role was sent from the role selector, validate it matches
    if (role && role !== user.role) {
      return res.status(401).json({
        success: false,
        message: `This account is not a ${role}. Please select the correct role.`,
      });
    }

    // Save user to session
    req.session.user = {
      user_id:        user.user_id,
      name:           user.name,
      email:          user.email,
      role:           user.role,
      specialization: user.specialization,
    };

    res.json({ success: true, message: 'Login successful.', user: req.session.user });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── POST /api/auth/logout ───────────────────────────────────────────────────

exports.logout = (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Logout failed.' });
    }
    res.json({ success: true, message: 'Logged out.' });
  });
};

// ── GET /api/auth/me ────────────────────────────────────────────────────────

exports.getMe = (req, res) => {
  res.json({ success: true, user: req.session.user });
};
