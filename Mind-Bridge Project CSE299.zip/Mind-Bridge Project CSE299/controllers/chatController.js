// controllers/chatController.js
// Manages messages between students and peer supporters.
// Respects anonymous mode: if is_anonymous=true, receivers see 'Anonymous'.

const db = require('../config/db');

// ─── POST /api/messages ───────────────────────────────────────────────────
// Send a message to another user.

exports.sendMessage = async (req, res) => {
  try {
    const sender_id = req.user.user_id;
    const { receiver_id, message_text, is_anonymous } = req.body;

    if (!receiver_id || !message_text || message_text.trim() === '') {
      return res.status(400).json({ success: false, message: 'Receiver and message text are required.' });
    }

    // Validate receiver exists
    const [recvRows] = await db.query('SELECT user_id FROM users WHERE user_id = ?', [receiver_id]);
    if (recvRows.length === 0) {
      return res.status(404).json({ success: false, message: 'Receiver not found.' });
    }

    const anonymous = is_anonymous ? 1 : 0;

    const [result] = await db.query(
      'INSERT INTO messages (sender_id, receiver_id, message_text, is_anonymous) VALUES (?, ?, ?, ?)',
      [sender_id, receiver_id, message_text.trim(), anonymous]
    );

    res.status(201).json({
      success: true,
      message_id: result.insertId,
      sent_at: new Date(),
    });
  } catch (err) {
    console.error('SendMessage error:', err);
    res.status(500).json({ success: false, message: 'Server error sending message.' });
  }
};

// ─── GET /api/messages/conversation/:otherUserId ─────────────────────────
// Fetch full chat history between current user and another user.
// If a message is anonymous, the receiver sees sender as 'Anonymous'.

exports.getConversation = async (req, res) => {
  try {
    const my_id    = req.user.user_id;
    const other_id = parseInt(req.params.otherUserId);

    const [rows] = await db.query(
      `SELECT
         m.message_id,
         m.sender_id,
         CASE
           WHEN m.is_anonymous = 1 AND m.sender_id != ? THEN 'Anonymous'
           ELSE u.name
         END AS sender_name,
         m.receiver_id,
         m.message_text,
         m.is_anonymous,
         m.sent_at
       FROM messages m
       LEFT JOIN users u ON m.sender_id = u.user_id
       WHERE (m.sender_id = ? AND m.receiver_id = ?)
          OR (m.sender_id = ? AND m.receiver_id = ?)
       ORDER BY m.sent_at ASC`,
      [my_id, my_id, other_id, other_id, my_id]
    );

    res.json({ success: true, messages: rows });
  } catch (err) {
    console.error('GetConversation error:', err);
    res.status(500).json({ success: false, message: 'Server error fetching conversation.' });
  }
};

// ─── GET /api/messages/inbox ─────────────────────────────────────────────
// Returns all unique conversations for the current user (like an inbox list).

exports.getInbox = async (req, res) => {
  try {
    const my_id = req.user.user_id;

    // Get the most recent message per conversation partner
    const [rows] = await db.query(
      `SELECT
         latest.other_user_id,
         CASE
           WHEN latest.is_anonymous = 1 AND latest.sender_id != ? THEN 'Anonymous'
           ELSE u.name
         END AS other_user_name,
         u.role AS other_user_role,
         latest.message_text AS last_message,
         latest.sent_at AS last_sent_at
       FROM (
         SELECT
           CASE WHEN sender_id = ? THEN receiver_id ELSE sender_id END AS other_user_id,
           sender_id,
           message_text,
           is_anonymous,
           sent_at,
           ROW_NUMBER() OVER (
             PARTITION BY LEAST(sender_id, receiver_id), GREATEST(sender_id, receiver_id)
             ORDER BY sent_at DESC
           ) AS rn
         FROM messages
         WHERE sender_id = ? OR receiver_id = ?
       ) latest
       LEFT JOIN users u ON u.user_id = latest.other_user_id
       WHERE latest.rn = 1
       ORDER BY latest.sent_at DESC`,
      [my_id, my_id, my_id, my_id]
    );

    res.json({ success: true, conversations: rows });
  } catch (err) {
    console.error('GetInbox error:', err);
    res.status(500).json({ success: false, message: 'Server error fetching inbox.' });
  }
};
