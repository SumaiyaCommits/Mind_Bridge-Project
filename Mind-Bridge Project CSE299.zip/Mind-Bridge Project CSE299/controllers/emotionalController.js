// controllers/emotionalController.js
// Students log daily emotional scores; these power the dashboard chart.

const db = require('../config/db');

// ─── POST /api/emotional-tracking ─────────────────────────────────────────
// Student logs today's emotional score (1–10).

exports.logEmotionalScore = async (req, res) => {
  try {
    const student_id = req.user.user_id;
    const { emotional_score, recorded_date } = req.body;

    if (emotional_score === undefined || emotional_score === null) {
      return res.status(400).json({ success: false, message: 'emotional_score is required.' });
    }

    const score = parseInt(emotional_score);
    if (isNaN(score) || score < 1 || score > 10) {
      return res.status(400).json({ success: false, message: 'emotional_score must be a number between 1 and 10.' });
    }

    const date = recorded_date || new Date().toISOString().split('T')[0]; // defaults to today

    // Upsert: if a score already exists for this student on this date, update it
    await db.query(
      `INSERT INTO emotional_tracking (student_id, emotional_score, recorded_date)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE emotional_score = VALUES(emotional_score)`,
      [student_id, score, date]
    );

    res.status(201).json({ success: true, message: 'Emotional score logged.', date, score });
  } catch (err) {
    console.error('LogEmotionalScore error:', err);
    res.status(500).json({ success: false, message: 'Server error logging score.' });
  }
};

// ─── GET /api/emotional-tracking ─────────────────────────────────────────
// Returns the current student's emotional scores for the last 7 days (chart data).

exports.getMyEmotionalData = async (req, res) => {
  try {
    const student_id = req.user.user_id;

    const [rows] = await db.query(
      `SELECT emotional_score, recorded_date
       FROM emotional_tracking
       WHERE student_id = ?
       ORDER BY recorded_date DESC
       LIMIT 30`,
      [student_id]
    );

    res.json({ success: true, data: rows });
  } catch (err) {
    console.error('GetEmotionalData error:', err);
    res.status(500).json({ success: false, message: 'Server error fetching data.' });
  }
};

// ─── GET /api/emotional-tracking/student/:id ──────────────────────────────
// Supervisor/Peer: view a specific student's emotional trend.

exports.getStudentEmotionalData = async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await db.query(
      `SELECT emotional_score, recorded_date
       FROM emotional_tracking
       WHERE student_id = ?
       ORDER BY recorded_date DESC
       LIMIT 30`,
      [id]
    );

    res.json({ success: true, data: rows });
  } catch (err) {
    console.error('GetStudentEmotionalData error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};
