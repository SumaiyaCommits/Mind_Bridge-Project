// controllers/reportController.js
// Handles creating and fetching mental health reports.
// Students can submit anonymous or open reports.
// Supervisors can view all reports and update status.

const db = require('../config/db');

// ─── POST /api/reports ─────────────────────────────────────────────────────
// Student submits a new report. If anonymous, student_id is stored but
// NOT returned to peer supporters (only supervisors see it in emergencies).

exports.createReport = async (req, res) => {
  try {
    const { report_type, description, risk_level } = req.body;
    const student_id = req.user.user_id;

    if (!description || !risk_level) {
      return res.status(400).json({ success: false, message: 'Description and risk level are required.' });
    }

    const validRiskLevels = ['low', 'medium', 'high'];
    if (!validRiskLevels.includes(risk_level)) {
      return res.status(400).json({ success: false, message: 'Risk level must be low, medium, or high.' });
    }

    const type = report_type === 'anonymous' ? 'anonymous' : 'open';

    const [result] = await db.query(
      'INSERT INTO reports (student_id, report_type, description, risk_level, status) VALUES (?, ?, ?, ?, ?)',
      [student_id, type, description, risk_level, 'pending']
    );

    const reportId = result.insertId;

    // Automatically create an alert for high-risk reports
    if (risk_level === 'high') {
      await db.query(
        "INSERT INTO alerts (report_id, alert_type, status) VALUES (?, 'High Risk Mental Health Alert', 'unread')",
        [reportId]
      );
    }

    res.status(201).json({
      success: true,
      message: type === 'anonymous'
        ? 'Anonymous report submitted securely. Your identity is protected.'
        : 'Report submitted successfully.',
      report_id: reportId,
    });
  } catch (err) {
    console.error('CreateReport error:', err);
    res.status(500).json({ success: false, message: 'Server error creating report.' });
  }
};

// ─── GET /api/reports ──────────────────────────────────────────────────────
// Supervisors see ALL reports with student names.
// Peer supporters see open reports (anonymous ones hide the name).
// Students see only their own reports.

exports.getReports = async (req, res) => {
  try {
    const { role, user_id } = req.user;
    let rows;

    if (role === 'supervisor') {
      // Full visibility
      [rows] = await db.query(
        `SELECT r.*, u.name AS student_name, u.email AS student_email
         FROM reports r
         LEFT JOIN users u ON r.student_id = u.user_id
         ORDER BY r.created_at DESC`
      );
    } else if (role === 'peer') {
      // Open reports show name; anonymous reports show "Anonymous"
      [rows] = await db.query(
        `SELECT r.report_id, r.report_type, r.description, r.risk_level, r.status, r.created_at,
                CASE WHEN r.report_type = 'anonymous' THEN 'Anonymous' ELSE u.name END AS student_name
         FROM reports r
         LEFT JOIN users u ON r.student_id = u.user_id
         WHERE r.status != 'closed'
         ORDER BY r.created_at DESC`
      );
    } else {
      // Student: own reports only
      [rows] = await db.query(
        'SELECT report_id, report_type, description, risk_level, status, created_at FROM reports WHERE student_id = ? ORDER BY created_at DESC',
        [user_id]
      );
    }

    res.json({ success: true, reports: rows });
  } catch (err) {
    console.error('GetReports error:', err);
    res.status(500).json({ success: false, message: 'Server error fetching reports.' });
  }
};

// ─── GET /api/reports/:id ─────────────────────────────────────────────────

exports.getReportById = async (req, res) => {
  try {
    const { id } = req.params;
    const { role, user_id } = req.user;

    const [rows] = await db.query(
      `SELECT r.*, u.name AS student_name, u.email AS student_email
       FROM reports r LEFT JOIN users u ON r.student_id = u.user_id
       WHERE r.report_id = ?`,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Report not found.' });
    }

    const report = rows[0];

    // Students can only view their own reports
    if (role === 'student' && report.student_id !== user_id) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    // Peer supporters don't see identity for anonymous reports
    if (role === 'peer' && report.report_type === 'anonymous') {
      report.student_name  = 'Anonymous';
      report.student_email = null;
      report.student_id    = null;
    }

    res.json({ success: true, report });
  } catch (err) {
    console.error('GetReportById error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ─── PATCH /api/reports/:id/status ────────────────────────────────────────
// Supervisors and peer supporters can update report status.

exports.updateReportStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const validStatuses = ['pending', 'active', 'closed'];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Status must be pending, active, or closed.' });
    }

    const [result] = await db.query(
      'UPDATE reports SET status = ? WHERE report_id = ?',
      [status, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Report not found.' });
    }

    res.json({ success: true, message: `Report status updated to '${status}'.` });
  } catch (err) {
    console.error('UpdateReportStatus error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};
