// server.js
require('dotenv').config();

const express = require('express');
const cors    = require('cors');
const session = require('express-session');
const app     = express();

// ── Middleware ───────────────────────────────────────────────────────────────

app.use(cors({
  origin: true,           // allow all origins (frontend is a local file/Live Server)
  credentials: true,      // required for cookies/sessions to work cross-origin
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session setup — this replaces JWT entirely
app.use(session({
  secret: process.env.SESSION_SECRET || 'mind_bridge_secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  },
}));

// ── Health Check ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'Mind Bridge API is running.', timestamp: new Date().toISOString() });
});

// ── Routes ───────────────────────────────────────────────────────────────────
app.use('/api/auth',               require('./routes/auth'));
app.use('/api/reports',            require('./routes/reports'));
app.use('/api/sessions',           require('./routes/sessions'));
app.use('/api/messages',           require('./routes/chat'));
app.use('/api/alerts',             require('./routes/alerts'));
app.use('/api/resources',          require('./routes/resources'));
app.use('/api/emotional-tracking', require('./routes/emotional'));
app.use('/api/users',              require('./routes/users'));

// ── 404 ──────────────────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route not found: ${req.method} ${req.originalUrl}` });
});

// ── Error handler ─────────────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ success: false, message: 'An unexpected server error occurred.' });
});

// ── Start ─────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🚀  Mind Bridge API running at http://localhost:${PORT}`);
  console.log(`📋  Health check:  http://localhost:${PORT}/api/health\n`);
});
