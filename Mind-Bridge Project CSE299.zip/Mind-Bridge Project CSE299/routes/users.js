// routes/users.js
const express = require('express');
const router  = express.Router();
const { getUsers, getUserById, getDashboardStats } = require('../controllers/userController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect);

router.get('/dashboard-stats', authorize('supervisor'),             getDashboardStats); // GET /api/users/dashboard-stats
router.get('/',                authorize('supervisor'),             getUsers);           // GET /api/users?role=peer
router.get('/:id',             authorize('supervisor', 'peer'),    getUserById);        // GET /api/users/:id

module.exports = router;
