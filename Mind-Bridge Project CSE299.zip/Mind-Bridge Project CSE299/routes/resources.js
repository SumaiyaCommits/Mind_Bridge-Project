// routes/resources.js
const express = require('express');
const router  = express.Router();
const {
  getResources,
  createResource,
  updateResource,
  deleteResource,
} = require('../controllers/resourceController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect);

router.get('/',      getResources);                                       // GET    /api/resources
router.post('/',     authorize('supervisor'), createResource);            // POST   /api/resources
router.put('/:id',   authorize('supervisor'), updateResource);            // PUT    /api/resources/:id
router.delete('/:id',authorize('supervisor'), deleteResource);            // DELETE /api/resources/:id

module.exports = router;
