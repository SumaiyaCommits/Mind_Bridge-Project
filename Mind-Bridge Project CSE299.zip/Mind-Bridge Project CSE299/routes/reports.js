// routes/reports.js
const express = require('express');
const router  = express.Router();
const {
  createReport,
  getReports,
  getReportById,
  updateReportStatus,
} = require('../controllers/reportController');
const { protect, authorize } = require('../middleware/auth');

// All report routes require login
router.use(protect);

router.post('/',    authorize('student'),                    createReport);
router.get('/',                                              getReports);
router.get('/:id',                                           getReportById);
router.patch('/:id/status', authorize('supervisor', 'peer'), updateReportStatus);

module.exports = router;
