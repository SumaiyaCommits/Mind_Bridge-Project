// routes/chat.js
const express = require('express');
const router  = express.Router();
const { sendMessage, getConversation, getInbox } = require('../controllers/chatController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.post('/',                        sendMessage);       // POST   /api/messages
router.get('/inbox',                    getInbox);          // GET    /api/messages/inbox
router.get('/conversation/:otherUserId', getConversation);  // GET    /api/messages/conversation/:id

module.exports = router;
