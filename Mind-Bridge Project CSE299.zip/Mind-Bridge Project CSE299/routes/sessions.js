// routes/sessions.js
const express = require('express');
const router  = express.Router();
const {
  createSession,
  getSessions,
  updateSession,
  getAvailablePeers,
} = require('../controllers/sessionController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect);

router.get('/peers', getAvailablePeers);                              // GET  /api/sessions/peers
router.post('/',     authorize('student', 'supervisor'), createSession); // POST /api/sessions
router.get('/',      getSessions);                                      // GET  /api/sessions
router.patch('/:id', authorize('peer', 'supervisor'),   updateSession); // PATCH /api/sessions/:id

module.exports = router;
