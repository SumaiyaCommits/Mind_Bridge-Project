// routes/alerts.js
const express = require('express');
const router  = express.Router();
const { getAlerts, updateAlertStatus, getUnreadCount } = require('../controllers/alertController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect);
router.use(authorize('supervisor')); // All alert routes: supervisors only

router.get('/',                 getAlerts);         // GET   /api/alerts
router.get('/unread-count',     getUnreadCount);    // GET   /api/alerts/unread-count
router.patch('/:id/status',     updateAlertStatus); // PATCH /api/alerts/:id/status

module.exports = router;
