// routes/emotional.js
const express = require('express');
const router  = express.Router();
const {
  logEmotionalScore,
  getMyEmotionalData,
  getStudentEmotionalData,
} = require('../controllers/emotionalController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect);

router.post('/',               authorize('student'),               logEmotionalScore);        // POST /api/emotional-tracking
router.get('/',                authorize('student'),               getMyEmotionalData);       // GET  /api/emotional-tracking
router.get('/student/:id',     authorize('supervisor', 'peer'),   getStudentEmotionalData);  // GET  /api/emotional-tracking/student/:id

module.exports = router;
