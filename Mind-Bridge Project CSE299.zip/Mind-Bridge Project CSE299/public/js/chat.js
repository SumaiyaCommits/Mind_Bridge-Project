// chat.js — No JWT, no localStorage. Session cookie handles auth.

document.addEventListener('DOMContentLoaded', async () => {

  let user;
  try {
    const res = await API.auth.getMe();
    user = res.user;
  } catch { return; }

  const chatInput       = document.getElementById('chatInput');
  const sendBtn         = document.getElementById('sendBtn');
  const chatHistory     = document.getElementById('chatHistory');
  const anonymousToggle = document.getElementById('anonymousToggle');

  let currentReceiverId = 2; // default: first peer supporter
  let isAnonymous = false;

  // ── Load inbox sidebar ────────────────────────────────────────────────────
  try {
    const { conversations } = await API.messages.getInbox();
    const chatList = document.querySelector('.chat-list');
    if (chatList && conversations.length > 0) {
      chatList.innerHTML = '';
      conversations.forEach((conv, i) => {
        const item = document.createElement('div');
        item.className = 'chat-item' + (i === 0 ? ' chat-item--active' : '');
        item.innerHTML = `
          <div class="chat-item__avatar bg-blue"><i class="ph-fill ph-user"></i></div>
          <div class="chat-item__content">
            <div class="chat-item__top">
              <span class="chat-item__name">${esc(conv.other_user_name)}</span>
              <span class="chat-item__time">${fmtTime(conv.last_sent_at)}</span>
            </div>
            <p class="chat-item__preview">${esc(conv.last_message)}</p>
          </div>`;
        item.addEventListener('click', () => {
          document.querySelectorAll('.chat-item').forEach(el => el.classList.remove('chat-item--active'));
          item.classList.add('chat-item--active');
          currentReceiverId = conv.other_user_id;
          loadConversation();
          const nameEl = document.querySelector('.chat-window__name');
          if (nameEl) nameEl.textContent = conv.other_user_name;
        });
        chatList.appendChild(item);
      });
      if (conversations[0]) currentReceiverId = conversations[0].other_user_id;
    }
  } catch (err) { console.error('Inbox error:', err.message); }

  // ── Load conversation ─────────────────────────────────────────────────────
  async function loadConversation() {
    try {
      const { messages } = await API.messages.getConversation(currentReceiverId);
      chatHistory.innerHTML = '<div class="chat-date-divider"><span>Today</span></div>';
      messages.forEach(msg => {
        const type = msg.sender_id === user.user_id ? 'outgoing' : 'incoming';
        chatHistory.appendChild(createBubble(msg.message_text, type, msg.sent_at));
      });
      chatHistory.scrollTop = chatHistory.scrollHeight;
    } catch (err) { console.error('Conversation error:', err.message); }
  }

  // ── Send message ──────────────────────────────────────────────────────────
  async function sendMessage() {
    const text = chatInput.value.trim();
    if (!text) return;
    chatHistory.appendChild(createBubble(text, 'outgoing'));
    chatInput.value = '';
    chatHistory.scrollTop = chatHistory.scrollHeight;
    try {
      await API.messages.send(currentReceiverId, text, isAnonymous);
    } catch (err) {
      chatHistory.appendChild(createBubble('⚠ Failed to send. Try again.', 'incoming'));
    }
  }

  sendBtn?.addEventListener('click', sendMessage);
  chatInput?.addEventListener('keypress', e => { if (e.key === 'Enter') sendMessage(); });

  anonymousToggle?.addEventListener('change', e => {
    isAnonymous = e.target.checked;
    const msg = isAnonymous ? '🔒 Anonymous Mode ON.' : '👤 Anonymous Mode OFF.';
    chatHistory.appendChild(createBubble(msg, 'incoming'));
    chatHistory.scrollTop = chatHistory.scrollHeight;
  });

  // ── Helpers ───────────────────────────────────────────────────────────────
  function createBubble(text, type, ts = null) {
    const div = document.createElement('div');
    div.className = `message message--${type}`;
    div.innerHTML = `<div class="message__bubble">${esc(text)}</div>
                     <span class="message__time">${fmtTime(ts)}</span>`;
    return div;
  }
  function fmtTime(ts) {
    const d = ts ? new Date(ts) : new Date();
    let h = d.getHours(), m = d.getMinutes();
    const ap = h >= 12 ? 'PM' : 'AM';
    h = h % 12 || 12;
    return `${h}:${m < 10 ? '0'+m : m} ${ap}`;
  }
  function esc(str) {
    const d = document.createElement('div');
    d.textContent = str || '';
    return d.innerHTML;
  }

  loadConversation();
});
