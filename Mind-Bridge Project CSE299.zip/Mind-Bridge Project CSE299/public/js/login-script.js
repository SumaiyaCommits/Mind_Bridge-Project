// login-script.js
// Replaces the inline <script> block in login.html.
// Keeps the same role-selector logic as the original.
// Only difference: calls the API instead of just redirecting.

let selectedRole = 'student';
const roleOptions = document.querySelectorAll('.role-option');

roleOptions.forEach(option => {
  option.addEventListener('click', () => {
    roleOptions.forEach(opt => opt.classList.remove('selected'));
    option.classList.add('selected');
    selectedRole = option.getAttribute('data-role');
  });
});

async function handleLogin() {
  const email    = document.querySelector('input[type="text"]').value.trim();
  const password = document.querySelector('input[type="password"]').value;

  if (!email || !password) {
    alert('Please enter your email and password.');
    return;
  }

  const btn = document.querySelector('.btn--primary');
  btn.textContent = 'Signing in...';
  btn.disabled = true;

  try {
    const { user } = await API.auth.login(email, password, selectedRole);

    // Same redirect logic as the original
    if (user.role === 'student')         window.location.href = 'index.html';
    else if (user.role === 'peer')       window.location.href = 'schedule.html';
    else if (user.role === 'supervisor') window.location.href = 'clinical.html';

  } catch (err) {
    alert(err.message || 'Login failed. Please check your credentials.');
    btn.textContent = 'Sign In';
    btn.disabled = false;
  }
}

// Allow Enter key to submit
document.addEventListener('keydown', e => {
  if (e.key === 'Enter') handleLogin();
});
