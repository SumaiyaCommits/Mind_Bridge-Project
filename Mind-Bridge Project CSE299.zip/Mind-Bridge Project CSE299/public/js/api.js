// api.js
// Mind Bridge — Frontend API Client
// Uses sessions (cookies) only. No JWT. No localStorage tokens.
// Drop in your frontend folder and include BEFORE other scripts.
//
// Usage:
//   const { user } = await API.auth.login(email, password, role);
//   const { reports } = await API.reports.getAll();
//   await API.auth.logout();

const API_BASE = 'http://localhost:3000/api';

// ── Core fetch wrapper ────────────────────────────────────────────────────────
// credentials: 'include' sends the session cookie automatically on every request.
async function request(method, path, body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',   // <-- this is all that's needed for sessions
  };
  if (body) opts.body = JSON.stringify(body);

  const res  = await fetch(`${API_BASE}${path}`, opts);
  const data = await res.json();

  if (!res.ok) {
    if (res.status === 401) {
      // Not logged in — go back to login page
      window.location.href = 'login.html';
    }
    throw new Error(data.message || 'API error');
  }
  return data;
}

// ── API namespaces ────────────────────────────────────────────────────────────
const API = {

  // ── Auth ──────────────────────────────────────────────────────────────────
  auth: {
    async register(name, email, password, role, specialization = null) {
      return request('POST', '/auth/register', { name, email, password, role, specialization });
    },
    async login(email, password, role = null) {
      return request('POST', '/auth/login', { email, password, role });
    },
    async logout() {
      await request('POST', '/auth/logout');
      window.location.href = 'login.html';
    },
    async getMe() {
      return request('GET', '/auth/me');
    },
  },

  // ── Reports ───────────────────────────────────────────────────────────────
  reports: {
    async submit(description, risk_level, report_type = 'open') {
      return request('POST', '/reports', { description, risk_level, report_type });
    },
    async getAll() {
      return request('GET', '/reports');
    },
    async getById(id) {
      return request('GET', `/reports/${id}`);
    },
    async updateStatus(id, status) {
      return request('PATCH', `/reports/${id}/status`, { status });
    },
  },

  // ── Sessions ──────────────────────────────────────────────────────────────
  sessions: {
    async book(report_id, peer_id, session_date) {
      return request('POST', '/sessions', { report_id, peer_id, session_date });
    },
    async getAll() {
      return request('GET', '/sessions');
    },
    async update(id, status, notes = null) {
      return request('PATCH', `/sessions/${id}`, { status, notes });
    },
    async getAvailablePeers() {
      return request('GET', '/sessions/peers');
    },
  },

  // ── Messages / Chat ───────────────────────────────────────────────────────
  messages: {
    async send(receiver_id, message_text, is_anonymous = false) {
      return request('POST', '/messages', { receiver_id, message_text, is_anonymous });
    },
    async getConversation(otherUserId) {
      return request('GET', `/messages/conversation/${otherUserId}`);
    },
    async getInbox() {
      return request('GET', '/messages/inbox');
    },
  },

  // ── Alerts ────────────────────────────────────────────────────────────────
  alerts: {
    async getAll() {
      return request('GET', '/alerts');
    },
    async updateStatus(id, status) {
      return request('PATCH', `/alerts/${id}/status`, { status });
    },
    async getUnreadCount() {
      return request('GET', '/alerts/unread-count');
    },
  },

  // ── Resources ─────────────────────────────────────────────────────────────
  resources: {
    async getAll(type = null) {
      const qs = type ? `?type=${type}` : '';
      return request('GET', `/resources${qs}`);
    },
    async create(title, description, resource_type, duration_minutes = null) {
      return request('POST', '/resources', { title, description, resource_type, duration_minutes });
    },
    async update(id, fields) {
      return request('PUT', `/resources/${id}`, fields);
    },
    async delete(id) {
      return request('DELETE', `/resources/${id}`);
    },
  },

  // ── Emotional Tracking ────────────────────────────────────────────────────
  emotional: {
    async log(emotional_score, recorded_date = null) {
      return request('POST', '/emotional-tracking', { emotional_score, recorded_date });
    },
    async getMine() {
      return request('GET', '/emotional-tracking');
    },
    async getForStudent(id) {
      return request('GET', `/emotional-tracking/student/${id}`);
    },
  },

  // ── Users ─────────────────────────────────────────────────────────────────
  users: {
    async getAll(role = null) {
      const qs = role ? `?role=${role}` : '';
      return request('GET', `/users${qs}`);
    },
    async getById(id) {
      return request('GET', `/users/${id}`);
    },
    async getDashboardStats() {
      return request('GET', '/users/dashboard-stats');
    },
  },
};

window.API = API;
