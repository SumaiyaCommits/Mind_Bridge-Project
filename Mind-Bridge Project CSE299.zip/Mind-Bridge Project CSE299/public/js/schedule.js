// schedule.js — No JWT, no localStorage.

document.addEventListener('DOMContentLoaded', async () => {

  let user;
  try {
    const res = await API.auth.getMe();
    user = res.user;
  } catch { return; }

  // ── Static appointment cards (original design) ────────────────────────────
  const appointments = [
    { col:'col-darlene', top:120, height:100, title:'Nichols Family',    type:'Family Consultation',          time:'',                    dot:'',        striped:false },
    { col:'col-darlene', top:260, height:100, title:'Adam Bridges',      type:'Private Consultation',         time:'09:00 am - 10:00 am', dot:'#c084fc', striped:false },
    { col:'col-darlene', top:380, height:100, title:'Teresa Moore',      type:'Private Consultation - Child', time:'09:00 am - 10:00 am', dot:'#fde047', striped:false },
    { col:'col-darlene', top:600, height:100, title:'Nichols Family',    type:'Family Consultation',          time:'',                    dot:'',        striped:false },
    { col:'col-michael', top: 20, height:100, title:'Ruby Jackson',      type:'Private Consultation',         time:'09:00 am - 10:00 am', dot:'#93c5fd', striped:true  },
    { col:'col-michael', top:200, height:100, title:'Darlene Robertson', type:'Group Consultation',           time:'09:00 am - 10:00 am', dot:'#93c5fd', striped:false },
    { col:'col-michael', top:440, height:100, title:'Shirley Cummings',  type:'Private Consultation',         time:'02:30 am - 03:30 am', dot:'#93c5fd', striped:false },
    { col:'col-max',     top: 20, height:140, title:'Darlene Robertson', type:'Group Consultation',           time:'09:00 am - 10:30 am', dot:'#93c5fd', striped:true  },
    { col:'col-max',     top:240, height:140, title:'Diane Walker',      type:'Private Consultation - Child', time:'12:00 am - 1:30 pm',  dot:'#fde047', striped:false },
    { col:'col-max',     top:500, height:100, title:'Sean Duncan',       type:'Private Consultation',         time:'02:00 pm - 03:00 pm', dot:'#c084fc', striped:false },
    { col:'col-mccoy',   top:120, height:100, title:'Max Worthington',   type:'Group Consultation',           time:'',                    dot:'',        striped:false },
    { col:'col-mccoy',   top:360, height:100, title:'Nichols Family',    type:'Family Consultation',          time:'09:00 am - 10:00 am', dot:'#86efac', striped:false },
  ];

  appointments.forEach(app => {
    const col = document.getElementById(app.col);
    if (!col) return;
    const card = document.createElement('div');
    card.className = `appointment-card ${app.striped ? 'striped' : ''}`;
    card.style.top    = `${app.top}px`;
    card.style.height = `${app.height}px`;
    let html = `<h4>${app.title}</h4><p>${app.type}</p>`;
    if (app.time) html += `<span class="time">${app.time}</span>`;
    if (app.dot)  html += `<div class="status-dot" style="background-color:${app.dot};"></div>`;
    card.innerHTML = html;
    col.appendChild(card);
  });

  const line = document.getElementById('nichols-line');
  if (line) { line.style.top='170px'; line.style.left='0'; line.style.width='85%'; }

  // ── "Add new" button — booking modal for students ──────────────────────
  const addBtn = document.querySelector('.calendar-header-top .btn--primary');
  if (addBtn && user.role === 'student') {
    addBtn.addEventListener('click', openBookingModal);
  }

  async function openBookingModal() {
    let peers = [];
    try { const r = await API.sessions.getAvailablePeers(); peers = r.peers; }
    catch { alert('Could not load peer supporters.'); return; }

    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:1000;display:flex;align-items:center;justify-content:center;';
    modal.innerHTML = `
      <div style="background:white;border-radius:24px;padding:32px;width:400px;max-width:90vw;">
        <h3 style="margin-bottom:20px;">Book a Peer Support Session</h3>
        <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">Peer Supporter</label>
        <select id="bp" style="width:100%;padding:12px;border:1px solid #e2e8f0;border-radius:12px;font-size:14px;margin-bottom:14px;">
          ${peers.map(p=>`<option value="${p.user_id}">${p.name}${p.specialization?' — '+p.specialization:''}</option>`).join('')}
        </select>
        <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">Date & Time</label>
        <input type="datetime-local" id="bd" style="width:100%;padding:12px;border:1px solid #e2e8f0;border-radius:12px;font-size:14px;box-sizing:border-box;margin-bottom:14px;">
        <label style="display:block;font-size:13px;font-weight:600;margin-bottom:6px;">Your Report ID</label>
        <input type="number" id="br" placeholder="e.g. 3" style="width:100%;padding:12px;border:1px solid #e2e8f0;border-radius:12px;font-size:14px;box-sizing:border-box;margin-bottom:22px;">
        <div style="display:flex;gap:12px;">
          <button id="bc" style="flex:1;padding:12px;border:1px solid #e2e8f0;border-radius:50px;background:white;cursor:pointer;">Cancel</button>
          <button id="bb" style="flex:1;padding:12px;border:none;border-radius:50px;background:#151A26;color:white;cursor:pointer;font-weight:500;">Book Session</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
    document.getElementById('bc').onclick = () => modal.remove();
    document.getElementById('bb').onclick = async () => {
      const peer_id   = document.getElementById('bp').value;
      const date      = document.getElementById('bd').value;
      const report_id = document.getElementById('br').value;
      if (!peer_id || !date || !report_id) { alert('Please fill all fields.'); return; }
      try {
        await API.sessions.book(parseInt(report_id), parseInt(peer_id), date);
        modal.remove();
        alert('✅ Session booked successfully!');
      } catch (err) { alert(err.message || 'Booking failed.'); }
    };
  }

  // ── Checkbox filters (visual only, same as original) ──────────────────────
  document.querySelectorAll('.custom-checkbox-container input').forEach(cb => {
    cb.addEventListener('change', e => console.log('Filter toggled:', e.target.checked));
  });
});
