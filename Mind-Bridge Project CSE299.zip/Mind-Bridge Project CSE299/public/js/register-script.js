// register-script.js
// Replaces the onclick in register.html's button.

async function handleRegister() {
  const inputs   = document.querySelectorAll('.form-control');
  const name     = inputs[0]?.value.trim();
  const email    = inputs[2]?.value.trim();
  const password = inputs[3]?.value;

  if (!name || !email || !password) {
    alert('Please fill in all required fields.');
    return;
  }

  const btn = document.querySelector('.btn--primary');
  btn.textContent = 'Creating account...';
  btn.disabled = true;

  try {
    await API.auth.register(name, email, password, 'student');
    window.location.href = 'index.html';
  } catch (err) {
    alert(err.message || 'Registration failed.');
    btn.textContent = 'Create Account';
    btn.disabled = false;
  }
}
