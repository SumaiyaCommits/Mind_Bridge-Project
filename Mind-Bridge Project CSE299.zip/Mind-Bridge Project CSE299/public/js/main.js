// main.js — Student dashboard. No JWT, no localStorage.

document.addEventListener('DOMContentLoaded', async () => {

  // Get current user from session (server checks cookie)
  let user;
  try {
    const res = await API.auth.getMe();
    user = res.user;
  } catch {
    return; // api.js already redirects to login.html on 401
  }

  // Personalize greeting
  const greetingEl = document.querySelector('.topbar__greeting');
  if (greetingEl) {
    greetingEl.innerHTML = `Welcome back, ${user.name.split(' ')[0]}! <span class="wave">🙌</span>`;
  }

  // Update profile picture
  const profilePic = document.querySelector('.profile-pic');
  if (profilePic) {
    profilePic.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=0D8ABC&color=fff`;
  }

  // Gear icon = logout
  const gearBtn = document.querySelector('.ph-gear')?.closest('.icon-btn');
  if (gearBtn) {
    gearBtn.title = 'Logout';
    gearBtn.addEventListener('click', () => {
      if (confirm('Log out?')) API.auth.logout();
    });
  }

  // ── Emotional chart ───────────────────────────────────────────────────────
  const chartContainer = document.getElementById('emotionalChart');
  if (chartContainer && user.role === 'student') {
    try {
      const { data } = await API.emotional.getMine();

      const today = new Date();
      const days  = Array.from({ length: 7 }, (_, i) => {
        const d = new Date(today);
        d.setDate(today.getDate() - (6 - i));
        return {
          label:   d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }),
          dateStr: d.toISOString().split('T')[0],
        };
      });

      const scoreMap = {};
      data.forEach(row => { scoreMap[row.recorded_date?.split('T')[0]] = row.emotional_score; });

      chartContainer.innerHTML = '';
      days.forEach(d => {
        const score  = (scoreMap[d.dateStr] ?? Math.floor(Math.random() * 4) + 3) * 10;
        const barGroup  = document.createElement('div');
        barGroup.className = 'chart-bar-group';
        const barWrapper = document.createElement('div');
        barWrapper.className = 'chart-bar-wrapper';
        const barBg   = document.createElement('div');
        barBg.className   = 'chart-bar-bg';
        barBg.style.height = '90%';
        const barFill = document.createElement('div');
        barFill.className   = 'chart-bar-fill';
        barFill.style.height = `${score}%`;
        const label = document.createElement('div');
        label.className   = 'chart-label';
        label.textContent = d.label;
        barWrapper.appendChild(barBg);
        barWrapper.appendChild(barFill);
        barGroup.appendChild(barWrapper);
        barGroup.appendChild(label);
        chartContainer.appendChild(barGroup);
      });
    } catch (err) {
      console.error('Chart error:', err.message);
    }
  }

  // ── Upcoming sessions ─────────────────────────────────────────────────────
  const appointmentList = document.querySelector('.appointment-list');
  if (appointmentList && user.role === 'student') {
    try {
      const { sessions } = await API.sessions.getAll();
      const upcoming = sessions.filter(s => s.status === 'scheduled').slice(0, 2);
      if (upcoming.length > 0) {
        appointmentList.innerHTML = '';
        upcoming.forEach(s => {
          const d    = new Date(s.session_date);
          const name = s.peer_name || 'Peer Supporter';
          appointmentList.innerHTML += `
            <div class="appointment">
              <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=10B981&color=fff" class="avatar" alt="${name}">
              <div class="appointment__info">
                <h4>${name}</h4>
                <p>${s.peer_specialization || 'Peer Supporter'}</p>
              </div>
              <div class="appointment__time">
                <span class="time">${d.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'})}</span>
                <span class="date">${d.toLocaleDateString('en-GB',{day:'numeric',month:'short'})}</span>
              </div>
            </div>`;
        });
      }
    } catch (err) {
      console.error('Sessions error:', err.message);
    }
  }

  // ── Supervisor alert badge ────────────────────────────────────────────────
  if (user.role === 'supervisor') {
    try {
      const { count } = await API.alerts.getUnreadCount();
      if (count > 0) {
        const bell = document.querySelector('.ph-bell')?.closest('.icon-btn');
        if (bell) {
          bell.style.position = 'relative';
          bell.insertAdjacentHTML('beforeend',
            `<span style="position:absolute;top:4px;right:4px;background:#ef4444;color:white;
              border-radius:50%;width:16px;height:16px;font-size:10px;display:flex;
              align-items:center;justify-content:center;">${count}</span>`);
        }
      }
    } catch (_) {}
  }
});
