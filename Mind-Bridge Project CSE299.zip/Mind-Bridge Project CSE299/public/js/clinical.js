// clinical.js — Supervisor case table. No JWT.

document.addEventListener('DOMContentLoaded', async () => {

  let user;
  try {
    const res = await API.auth.getMe();
    user = res.user;
  } catch { return; }

  const profilePic = document.querySelector('.profile-pic');
  if (profilePic) profilePic.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=0D8ABC&color=fff`;

  const tbody = document.querySelector('.clinical-table tbody');
  if (!tbody) return;

  try {
    const { reports } = await API.reports.getAll();
    if (reports.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#64748b;padding:32px;">No active cases.</td></tr>';
      return;
    }

    tbody.innerHTML = '';
    reports.forEach(r => {
      const riskClass = { high:'badge--danger', medium:'badge--warning', low:'badge--success' }[r.risk_level] || 'badge--info';
      const riskLabel = { high:'High Risk', medium:'Medium', low:'Stable' }[r.risk_level] || r.risk_level;
      const name      = r.report_type === 'anonymous' ? '<em>Anonymous</em>' : `<strong>${esc(r.student_name||'Unknown')}</strong>`;
      const btn       = r.status === 'pending'
        ? `<button class="btn btn--primary assign-btn" data-id="${r.report_id}">Assign Support</button>`
        : `<button class="btn btn--outline review-btn" data-id="${r.report_id}">Review Notes</button>`;

      tbody.innerHTML += `
        <tr>
          <td>#RPT-${r.report_id}</td>
          <td>${name}</td>
          <td><span class="badge ${riskClass}">${riskLabel}</span></td>
          <td>${esc(r.report_type === 'open' ? (r.student_name||'—') : 'Anonymous')}</td>
          <td>${fmtAgo(r.created_at)}</td>
          <td>${btn}</td>
        </tr>`;
    });

    tbody.querySelectorAll('.review-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        const { report } = await API.reports.getById(btn.dataset.id);
        alert(`Report #${report.report_id}\nRisk: ${report.risk_level}\nStatus: ${report.status}\n\n${report.description}`);
      });
    });

    tbody.querySelectorAll('.assign-btn').forEach(btn => {
      btn.addEventListener('click', () => openAssignModal(btn.dataset.id));
    });

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#ef4444;padding:32px;">${err.message}</td></tr>`;
  }

  async function openAssignModal(reportId) {
    const { peers } = await API.sessions.getAvailablePeers();
    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:1000;display:flex;align-items:center;justify-content:center;';
    modal.innerHTML = `
      <div style="background:white;border-radius:24px;padding:32px;width:380px;">
        <h3 style="margin-bottom:20px;">Assign Peer Supporter</h3>
        <select id="ap" style="width:100%;padding:12px;border:1px solid #e2e8f0;border-radius:12px;margin-bottom:12px;font-size:14px;">
          ${peers.map(p=>`<option value="${p.user_id}">${p.name}${p.specialization?' — '+p.specialization:''}</option>`).join('')}
        </select>
        <input type="datetime-local" id="ad" style="width:100%;padding:12px;border:1px solid #e2e8f0;border-radius:12px;font-size:14px;box-sizing:border-box;margin-bottom:20px;">
        <div style="display:flex;gap:12px;">
          <button id="ac" style="flex:1;padding:12px;border:1px solid #e2e8f0;border-radius:50px;background:white;cursor:pointer;">Cancel</button>
          <button id="af" style="flex:1;padding:12px;border:none;border-radius:50px;background:#151A26;color:white;cursor:pointer;">Assign</button>
        </div>
      </div>`;
    document.body.appendChild(modal);
    document.getElementById('ac').onclick = () => modal.remove();
    document.getElementById('af').onclick = async () => {
      const peer_id = document.getElementById('ap').value;
      const date    = document.getElementById('ad').value;
      if (!date) { alert('Please select a date.'); return; }
      try {
        await API.sessions.book(parseInt(reportId), parseInt(peer_id), date);
        await API.reports.updateStatus(reportId, 'active');
        modal.remove();
        alert('Peer supporter assigned!');
        location.reload();
      } catch (err) { alert(err.message); }
    };
  }

  function esc(s) { const d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }
  function fmtAgo(ts) {
    if (!ts) return '—';
    const m = Math.floor((Date.now()-new Date(ts).getTime())/60000);
    if (m<1) return 'Just now'; if (m<60) return m+' min ago';
    if (m<1440) return Math.floor(m/60)+' hours ago';
    return Math.floor(m/1440)+' days ago';
  }
});
