// resources.js — No JWT, no localStorage.

document.addEventListener('DOMContentLoaded', async () => {

  try { await API.auth.getMe(); }
  catch { return; }

  const grid       = document.querySelector('.resource-grid');
  const toggleBtns = document.querySelectorAll('.toggle-group .toggle-btn');

  toggleBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      toggleBtns.forEach(b => b.classList.remove('toggle-btn--active'));
      btn.classList.add('toggle-btn--active');
      const label = btn.textContent.trim().toLowerCase();
      loadResources(label === 'all' ? null : label);
    });
  });

  async function loadResources(type = null) {
    if (!grid) return;
    try {
      const { resources } = await API.resources.getAll(type);
      if (resources.length === 0) {
        grid.innerHTML = '<p style="color:#64748b;padding:32px;">No resources found.</p>';
        return;
      }
      const grads = ['bg-gradient-1','bg-gradient-2','bg-gradient-3','bg-gradient-4','bg-gradient-5','bg-gradient-6'];
      const icons = { article:'ph-books', video:'ph-play-circle', exercise:'ph-activity', guide:'ph-brain' };
      const acts  = { article:'Read', video:'Watch', exercise:'Start', guide:'Read' };
      grid.innerHTML = resources.map((r, i) => `
        <div class="card resource-card">
          <div class="resource-card__image ${grads[i%grads.length]}">
            <i class="ph-fill ${icons[r.resource_type]||'ph-book-open'}"></i>
          </div>
          <div class="resource-card__content">
            <span class="resource-badge">${cap(r.resource_type)}</span>
            <h3 class="resource-title">${esc(r.title)}</h3>
            <p class="resource-desc">${esc(r.description||'')}</p>
            <div class="resource-meta">
              <span><i class="ph ph-clock"></i> ${r.duration_minutes ? r.duration_minutes+' min' : '—'}</span>
              <button class="btn btn--outline btn--sm">${acts[r.resource_type]||'Open'}</button>
            </div>
          </div>
        </div>`).join('');
    } catch (err) {
      console.error('Resources error:', err.message);
      // Leave the static cards in place as fallback
    }
  }

  function esc(s) { const d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }
  function cap(s) { return s ? s[0].toUpperCase()+s.slice(1) : ''; }

  loadResources();
});
