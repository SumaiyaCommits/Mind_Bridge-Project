// middleware/auth.js
// Simple session-based auth middleware.
// No JWT. No tokens. Just req.session.user set at login.

/**
 * protect(req, res, next)
 * Checks if the user is logged in via session.
 * If not, returns 401.
 */
function protect(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ success: false, message: 'Not logged in. Please log in first.' });
  }
  next();
}

/**
 * authorize(...roles)
 * Restricts a route to specific roles.
 * Usage: router.get('/route', protect, authorize('supervisor'), handler)
 */
function authorize(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.session.user.role)) {
      return res.status(403).json({
        success: false,
        message: `Access denied. Requires role: ${roles.join(' or ')}.`,
      });
    }
    next();
  };
}

module.exports = { protect, authorize };
