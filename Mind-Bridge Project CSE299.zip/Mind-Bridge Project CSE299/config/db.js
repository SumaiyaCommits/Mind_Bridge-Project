// config/db.js
// Manages MySQL connection pool using mysql2 + dotenv
const mysql = require('mysql2');
require('dotenv').config();

const pool = mysql.createPool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     process.env.DB_PORT     || 3306,
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME     || 'mind_bridge',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Promisify for async/await usage throughout the app
const db = pool.promise();

// Test connection on startup and print the connection string
pool.getConnection((err, connection) => {
  const connStr = `mysql://${process.env.DB_USER || 'root'}:${process.env.DB_PASSWORD ? '****' : '(no password)'}@${process.env.DB_HOST || 'localhost'}:${process.env.DB_PORT || 3306}/${process.env.DB_NAME || 'mind_bridge'}`;
  if (err) {
    console.error('❌  Database connection failed:', err.message);
    console.error('   Connection string tried:', connStr);
    console.error('   Make sure XAMPP MySQL is running and your .env values are correct.');
    return;
  }
  console.log('✅  Database connected:', connStr);
  connection.release();
});

module.exports = db;
