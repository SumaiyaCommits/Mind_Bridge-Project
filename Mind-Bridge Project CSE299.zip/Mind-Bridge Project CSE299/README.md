# Mind Bridge — Node.js Backend

REST API backend for the Mind Bridge student mental health platform.
Built with **Express.js**, **MySQL2**, and **express-session** (cookie-based auth — no JWT).

---

## Project Structure

```
mind-bridge-backend/
├── server.js                  ← Entry point
├── .env                       ← Your config (edit this)
├── package.json
│
├── config/db.js               ← MySQL connection pool
├── middleware/auth.js         ← Session-based protect + authorize
│
├── routes/                    ← One file per feature
├── controllers/               ← All business logic
│
└── public/js/                 ← Drop these into your frontend folder
    ├── api.js                 ← Shared API client (include first on every page)
    ├── login-script.js
    ├── register-script.js
    ├── main.js
    ├── chat.js
    ├── schedule.js
    ├── clinical.js
    └── resources.js
```

---

## Quick Start

### 1. Install
```bash
cd mind-bridge-backend
npm install
```

### 2. Database
- Start XAMPP → MySQL
- Open phpMyAdmin → create database `mind_bridge`
- Import `mind_bridge.sql`

### 3. Configure
Open `.env` — the defaults work for XAMPP:
```
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=        ← blank for XAMPP default
DB_NAME=mind_bridge
SESSION_SECRET=mind_bridge_session_secret
```

### 4. Run
```bash
npm run dev
```
```
✅  Database connected: mysql://root:(no password)@localhost:3306/mind_bridge
🚀  Mind Bridge API running at http://localhost:3000
```

### 5. Add files to your frontend
Copy all files from `public/js/` into your frontend folder (same folder as your HTML files).

---

## HTML Changes

### Fix CSS paths (all files use wrong `../css/` path)
Every HTML file needs `../css/` → just the filename:
```html
<!-- WRONG (what's currently in your files) -->
<link rel="stylesheet" href="../css/style.css">

<!-- CORRECT -->
<link rel="stylesheet" href="style.css">
```

### Script changes per file

**login.html** — replace the `<script>` block:
```html
<script src="api.js"></script>
<script src="login-script.js"></script>
```

**register.html** — add before `</body>`, change button onclick to `handleRegister()`:
```html
<script src="api.js"></script>
<script src="register-script.js"></script>
```

**index.html** — replace `<script src="src/main.js">`:
```html
<script src="api.js"></script>
<script src="main.js"></script>
```

**chat.html** — replace `<script src="../js/chat.js">`:
```html
<script src="api.js"></script>
<script src="chat.js"></script>
```

**schedule.html** — replace `<script src="../js/schedule.js">`:
```html
<script src="api.js"></script>
<script src="schedule.js"></script>
```

**clinical.html** — add before `</body>` (no script existed):
```html
<script src="api.js"></script>
<script src="clinical.js"></script>
```

**resources.html** — add before `</body>` (no script existed):
```html
<script src="api.js"></script>
<script src="resources.js"></script>
```

**crisis.html & help.html** — CSS path fix only, no JS needed.

---

## API Reference

All routes (except login/register) require being logged in.
Auth is handled by a **session cookie** — set automatically on login, sent automatically on every request. Nothing to manage manually.

### Auth
| Method | Endpoint            | Description |
|--------|---------------------|-------------|
| POST   | /api/auth/login     | Login |
| POST   | /api/auth/register  | Register |
| POST   | /api/auth/logout    | Logout |
| GET    | /api/auth/me        | Get current user |

### Reports
| Method | Endpoint                 | Who |
|--------|--------------------------|-----|
| POST   | /api/reports             | student |
| GET    | /api/reports             | all (role-filtered) |
| GET    | /api/reports/:id         | all |
| PATCH  | /api/reports/:id/status  | supervisor, peer |

### Sessions
| Method | Endpoint            | Who |
|--------|---------------------|-----|
| POST   | /api/sessions       | student |
| GET    | /api/sessions       | all (role-filtered) |
| PATCH  | /api/sessions/:id   | peer, supervisor |
| GET    | /api/sessions/peers | all |

### Messages
| Method | Endpoint                            |
|--------|-------------------------------------|
| POST   | /api/messages                       |
| GET    | /api/messages/inbox                 |
| GET    | /api/messages/conversation/:userId  |

### Alerts (supervisor only)
| Method | Endpoint                 |
|--------|--------------------------|
| GET    | /api/alerts              |
| GET    | /api/alerts/unread-count |
| PATCH  | /api/alerts/:id/status   |

### Resources
| Method | Endpoint            | Who |
|--------|---------------------|-----|
| GET    | /api/resources      | all |
| POST   | /api/resources      | supervisor |
| PUT    | /api/resources/:id  | supervisor |
| DELETE | /api/resources/:id  | supervisor |

### Emotional Tracking
| Method | Endpoint                           | Who |
|--------|------------------------------------|-----|
| POST   | /api/emotional-tracking            | student |
| GET    | /api/emotional-tracking            | student |
| GET    | /api/emotional-tracking/student/:id | supervisor, peer |

### Users
| Method | Endpoint                   | Who |
|--------|----------------------------|-----|
| GET    | /api/users                 | supervisor |
| GET    | /api/users/:id             | supervisor, peer |
| GET    | /api/users/dashboard-stats | supervisor |

---

## Test Accounts

| Email               | Password | Role       |
|---------------------|----------|------------|
| sadia@test.com      | 123456   | student    |
| shanjida@peer.com   | 123456   | peer       |
| ali@admin.com       | 123456   | supervisor |
